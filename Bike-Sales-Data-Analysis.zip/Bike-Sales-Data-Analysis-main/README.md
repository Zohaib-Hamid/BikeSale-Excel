# Bike-Sales-Data-Analysis

In this project, I took the data of people who bought bikes and analysed their status and finalized all the data into a dashboard.
